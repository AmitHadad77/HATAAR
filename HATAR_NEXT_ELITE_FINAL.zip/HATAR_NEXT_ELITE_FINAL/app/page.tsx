'use client';

import dynamic from 'next/dynamic';
import Navbar from '@/components/Navbar';
import IconSprite from '@/components/IconSprite';
import Hero from '@/components/Hero';
import ScrollProgress from '@/components/ScrollProgress';
import MobileCTA from '@/components/MobileCTA';

const Editorial = dynamic(() => import('@/components/Editorial'));
const Services = dynamic(() => import('@/components/Services'));
const Process = dynamic(() => import('@/components/Process'));
const Gallery = dynamic(() => import('@/components/Gallery'));
const Team = dynamic(() => import('@/components/Team'));
const Reviews = dynamic(() => import('@/components/Reviews'));
const FAQ = dynamic(() => import('@/components/FAQ'));
const Booking = dynamic(() => import('@/components/Booking'));
const Footer = dynamic(() => import('@/components/Footer'));

export default function Page() {
  return (
    <>
      <IconSprite />
      <ScrollProgress />
      <Navbar />
      <main>
        <Hero />
        <Editorial />
        <Services />
        <Process />
        <Gallery />
        <Team />
        <Reviews />
        <FAQ />
        <Booking />
      </main>
      <Footer />
      <MobileCTA />
    </>
  );
}
