import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'התער — מספרת גברים פרימיום',
  description: 'חוויית טיפוח גברית מוקפדת: תספורות, עיצוב זקן וגילוח מסורתי באווירה קלאסית עם סטנדרט מודרני.',
  metadataBase: new URL('https://example.com'),
  openGraph: {
    title: 'התער — הרבה יותר מתספורת',
    description: 'דיוק, מסורת וסטייל גברי בחוויית טיפוח פרימיום.',
    images: ['/og.svg'],
    locale: 'he_IL',
    type: 'website',
  },
  robots: { index: true, follow: true },
};

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="he" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Assistant:wght@400;500;600;700;800&family=Frank+Ruhl+Libre:wght@600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
