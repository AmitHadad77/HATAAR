'use client';

import Image from 'next/image';
import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';

const items = [
  ['/gallery/fade.webp', 'פייד מדורג', 'קווים נקיים ומעבר רך'],
  ['/gallery/beard.webp', 'עיצוב זקן', 'איזון צורה ונפח'],
  ['/gallery/shave.webp', 'גילוח חם', 'טקס קלאסי ומדויק'],
  ['/gallery/interior.webp', 'החלל', 'שקט, ניקיון ונוחות'],
] as const;

export default function Gallery() {
  const [active, setActive] = useState<number | null>(null);

  useEffect(() => {
    if (active === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setActive(null);
      if (event.key === 'ArrowLeft') setActive((active + 1) % items.length);
      if (event.key === 'ArrowRight') setActive((active - 1 + items.length) % items.length);
    };
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', onKey);
    };
  }, [active]);

  const move = (step: number) => {
    if (active === null) return;
    setActive((active + step + items.length) % items.length);
  };

  return (
    <section id="gallery">
      <div className="container">
        <div className="sectionHead">
          <span>עבודות נבחרות</span>
          <h2>כל סגנון מקבל את הקו שמתאים לו.</h2>
          <p>כל התמונות נטענות מקומית בפורמט WebP דרך Next Image, עם טעינה עצלה ו־sizes מותאם.</p>
        </div>
        <div className="gallery">
          {items.map((item, index) => (
            <button
              type="button"
              className={`shot s${index + 1}`}
              key={item[0]}
              onClick={() => setActive(index)}
              aria-label={`פתיחת תמונה: ${item[1]}`}
            >
              <Image
                src={item[0]}
                alt={`${item[1]} במספרת התער`}
                fill
                sizes="(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 40vw"
                quality={86}
              />
              <div><h3>{item[1]}</h3><span>{item[2]}</span></div>
            </button>
          ))}
        </div>
      </div>

      {active !== null && (
        <div className="lightbox" role="dialog" aria-modal="true" aria-label="גלריית עבודות">
          <button className="lightboxClose" onClick={() => setActive(null)} aria-label="סגירה"><X /></button>
          <button className="lightboxArrow lightboxNext" onClick={() => move(1)} aria-label="התמונה הבאה"><ChevronLeft /></button>
          <figure>
            <Image src={items[active][0]} alt={items[active][1]} fill priority sizes="95vw" quality={92} />
            <figcaption><strong>{items[active][1]}</strong><span>{items[active][2]}</span></figcaption>
          </figure>
          <button className="lightboxArrow lightboxPrev" onClick={() => move(-1)} aria-label="התמונה הקודמת"><ChevronRight /></button>
        </div>
      )}
    </section>
  );
}
