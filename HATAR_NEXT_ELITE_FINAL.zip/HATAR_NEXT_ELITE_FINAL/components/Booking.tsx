'use client';

import { FormEvent, useEffect, useState } from 'react';

export default function Booking() {
  const [done, setDone] = useState(false);
  const [selected, setSelected] = useState('');

  useEffect(() => {
    const handler = (event: Event) => setSelected((event as CustomEvent<string>).detail);
    addEventListener('hatar:service', handler);
    return () => removeEventListener('hatar:service', handler);
  }, []);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const text = `שלום, אשמח לבדוק תור בהתער.\n\nשם: ${data.get('name')}\nטלפון: ${data.get('phone')}\nשירות: ${data.get('service')}\nיום: ${data.get('day')}\nשעה: ${data.get('time')}\nהערה: ${data.get('note') || 'אין'}`;
    const url = `https://wa.me/972500000000?text=${encodeURIComponent(text)}`;
    const popup = window.open(url, '_blank', 'noopener,noreferrer');
    if (!popup) window.location.href = url;
    setDone(true);
  }

  return (
    <section className="booking" id="booking">
      <div className="container bookingLayout">
        <div className="sectionHead bookingIntro">
          <span>קביעת תור</span>
          <h2>בחר שירות. אנחנו נכין את הודעת ה־WhatsApp.</h2>
          <p>הטופס אינו שומר מידע. לפני פרסום מסחרי יש להחליף את מספר הדמו למספר העסק.</p>
          <div className="bookingBenefits">
            <span><b>01</b> בחירת שירות מראש</span>
            <span><b>02</b> זמן מועדף</span>
            <span><b>03</b> הודעה מוכנה לשליחה</span>
          </div>
        </div>
        <form onSubmit={submit}>
          {done ? (
            <div className="bookingSuccess" role="status">
              <i>✓</i><h3>ההודעה מוכנה</h3><p>WhatsApp נפתח עם כל פרטי הבקשה.</p>
            </div>
          ) : (
            <>
              <div className="formRow">
                <label>שם מלא<input name="name" autoComplete="name" required /></label>
                <label>טלפון<input name="phone" type="tel" autoComplete="tel" inputMode="tel" required /></label>
              </div>
              <label>שירות
                <select name="service" required value={selected} onChange={(event) => setSelected(event.target.value)}>
                  <option value="">בחר שירות</option>
                  <option>תספורת גברים מדויקת</option>
                  <option>תספורת ועיצוב זקן</option>
                  <option>גילוח מסורתי בתער</option>
                  <option>עיצוב זקן מקצועי</option>
                  <option>טיפוח פנים לגבר</option>
                  <option>תספורת ילדים</option>
                </select>
              </label>
              <div className="formRow">
                <label>יום<select name="day"><option>היום</option><option>מחר</option><option>בהמשך השבוע</option></select></label>
                <label>שעה<select name="time"><option>בוקר</option><option>צהריים</option><option>ערב</option></select></label>
              </div>
              <label>הערה<textarea name="note" placeholder="לדוגמה: פייד נמוך, עיצוב זקן או רגישות בעור" /></label>
              <button className="button primary" type="submit">פתיחת הודעת WhatsApp</button>
            </>
          )}
        </form>
      </div>
    </section>
  );
}
