export default function MobileCTA() {
  return (
    <nav className="mobileCTA" aria-label="פעולות מהירות">
      <a href="tel:0500000000" className="secondary">חיוג</a>
      <a href="#booking" className="primary">שריין כיסא</a>
    </nav>
  );
}
