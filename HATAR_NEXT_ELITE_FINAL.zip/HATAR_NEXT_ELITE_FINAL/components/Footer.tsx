export default function Footer() {
  return (
    <footer>
      <div className="container footerTopline">
        <span>EST. 2025</span>
        <strong>PRECISION · TRADITION · CHARACTER</strong>
      </div>
      <div className="container footerGrid">
        <div>
          <div className="brand"><span>ת</span><div><b>התער</b><small>מספרת גברים · פתח תקווה</small></div></div>
          <p>חוויית טיפוח גברית שמחברת בין מקצוענות קלאסית, סטייל מודרני ושירות אישי.</p>
        </div>
        <div><h4>ניווט</h4><a href="#services">שירותים</a><a href="#gallery">עבודות</a><a href="#reviews">ביקורות</a></div>
        <div><h4>החוויה</h4><a href="#story">הסיפור שלנו</a><a href="#team">הצוות</a><a href="#booking">קביעת תור</a></div>
        <div><h4>פרויקט</h4><span>Next.js</span><span>Next Image</span><span>GSAP + Framer Motion</span></div>
      </div>
      <div className="container footerBottom">© 2026 התער — פרויקט קונספט לתיק עבודות.</div>
    </footer>
  );
}
