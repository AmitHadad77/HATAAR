'use client';

import Image from 'next/image';
import { motion } from 'framer-motion';

export default function Hero() {
  return (
    <section className="hero" id="top">
      <div className="heroGlow heroGlowA" aria-hidden="true" />
      <div className="heroGlow heroGlowB" aria-hidden="true" />
      <div className="container heroLayout">
        <div className="heroCopy">
          <motion.div
            className="status"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          >
            <i /> פתוחים היום · מומלץ לבדוק זמינות
          </motion.div>

          {/* הכותרת נשמרה בדיוק כפי שהתבקשת */}
          <h1>
            <span>תספורת מדויקת.</span>
            <em>שירות שמרגישים.</em>
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            חוויית טיפוח גברית מוקפדת באווירה של פעם. תספורת מדויקת, גילוח מסורתי,
            וזמן איכות שהוא נטו שלך.
          </motion.p>

          <motion.div
            className="heroActions"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            <a className="button primary magneticButton" href="#booking">שריין כיסא</a>
            <a className="button secondary" href="#gallery">צפייה בעבודות</a>
          </motion.div>

          <div className="heroProof" aria-label="ביקורות לדוגמה">
            <b>★★★★★</b>
            <span>חוות דעת לדוגמה · תוכן דמו לתיק עבודות</span>
          </div>
        </div>

        <motion.figure
          className="heroMedia"
          initial={{ opacity: 0, y: 24, scale: 0.985 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.95, ease: [0.16, 1, 0.3, 1] }}
        >
          <Image
            src="/hero.webp"
            alt="מספרת התער — חוויית טיפוח גברית"
            fill
            priority
            quality={90}
            sizes="(max-width: 900px) 100vw, 50vw"
          />
          <figcaption>
            <strong>דיוק בכל זווית</strong>
            <span>הדמיית מותג מקומית ומאופטמת</span>
          </figcaption>
        </motion.figure>
      </div>
    </section>
  );
}
