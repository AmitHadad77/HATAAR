'use client';

import { motion } from 'framer-motion';

const items = [
  ['תספורת גברים מדויקת', 'התאמה אישית למבנה הפנים ולסטייל שלך — ממראה קלאסי ועד פייד מודרני, עם הקפדה על כל קו וגימור.', '₪90', '35 דקות'],
  ['תספורת ועיצוב זקן', 'חבילה מלאה שמאזנת בין השיער לזקן, עם קווי מסגרת נקיים ומראה אחיד שמחזיק לאורך זמן.', '₪140', '55 דקות'],
  ['גילוח מסורתי בתער', 'חוויית Hot Towel Shave מלאה: מגבת חמה, תער מסורתי וטיפול מרגיע לעור הפנים.', '₪120', '40 דקות'],
  ['עיצוב זקן מקצועי', 'קיצוץ, בניית צורה, איזון נפח וסימטריה — עם חומרי טיפוח איכותיים לזקן ולעור.', '₪60', '25 דקות'],
  ['טיפוח פנים לגבר', 'ניקוי, פילינג עדין ומסכה מרגיעה שמחזירים לעור מראה רענן ונקי.', '₪110', '30 דקות'],
  ['תספורת ילדים', 'גישה סבלנית, קצב רגוע ותוצאה מדויקת גם ללקוחות הצעירים שלנו.', '₪70', '30 דקות'],
] as const;

export default function Services() {
  return (
    <section id="services">
      <div className="container">
        <div className="sectionHead">
          <span>השירותים שלנו</span>
          <h2>כל שירות מתחיל בהקשבה ומסתיים בגימור מדויק.</h2>
          <p>בחר את הטיפול שמתאים לך. לפני שמתחילים נעשה תיאום קצר כדי לדייק את התוצאה.</p>
        </div>
        <div className="serviceGrid">
          {items.map((item, index) => (
            <motion.article
              whileHover={{ y: -5 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              className="service"
              key={item[0]}
            >
              <small>0{index + 1}</small>
              <h3>{item[0]}</h3>
              <p>{item[1]}</p>
              <div>
                <strong>{item[2]}</strong>
                <span>{item[3]}</span>
              </div>
              <a
                href="#booking"
                onClick={() => window.dispatchEvent(new CustomEvent('hatar:service', { detail: item[0] }))}
              >
                בחירת השירות ←
              </a>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
