import Image from 'next/image';

export default function Editorial() {
  return (
    <section className="editorial" id="story">
      <div className="container editorialLayout">
        <div className="editorialCopy">
          <span className="label">הסיפור של התער</span>
          <h2>הכבוד של הספרות הקלאסית. הדיוק של היום.</h2>
          <p>
            הקמנו את ״התער״ כי רצינו להחזיר את הכבוד למקצוע הספרות של פעם, אבל עם
            טאץ׳ מודרני. כאן אתה לא עוד לקוח שבא להסתפר וללכת — אצלנו זו חוויה.
            מהרגע שאתה מתיישב בכיסא, עם מוזיקה טובה ושתייה קלה בצד, ועד לרגע שאתה
            קם החוצה, המטרה היא שתצא חד, אלגנטי ובטוח בעצמך.
          </p>
          <ul>
            <li><b>01</b><span>התאמה אישית למבנה הפנים ולסטייל שלך</span></li>
            <li><b>02</b><span>טכניקה קלאסית עם גימור מודרני</span></li>
            <li><b>03</b><span>שגרת תחזוקה ברורה שקל ליישם בבית</span></li>
          </ul>
        </div>
        <figure>
          <Image
            src="/tools.webp"
            alt="כלי עבודה מקצועיים במספרת התער"
            fill
            sizes="(max-width: 900px) 100vw, 55vw"
            quality={86}
          />
          <figcaption>מסורת. דיוק. אופי.</figcaption>
        </figure>
      </div>
    </section>
  );
}
