'use client';

import { useEffect, useRef } from 'react';

const items = [
  ['01', 'מתאמים ציפיות', 'מגדירים את הסגנון, רמת התחזוקה ומה יחמיא למבנה הפנים.'],
  ['02', 'עובדים בדיוק', 'בנייה הדרגתית, בדיקה מכל זווית וגימור נקי עד לפרט האחרון.'],
  ['03', 'יוצאים בשליטה', 'מקבלים המלצה לטיפוח בבית ומועד נכון לביקור הבא.'],
];

export default function Process() {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    let context: { revert: () => void } | undefined;
    Promise.all([import('gsap'), import('gsap/ScrollTrigger')]).then(([gsapModule, triggerModule]) => {
      const gsap = gsapModule.default;
      gsap.registerPlugin(triggerModule.ScrollTrigger);
      context = gsap.context(() => {
        gsap.to('.processProgress', {
          scaleY: 1,
          ease: 'none',
          scrollTrigger: { trigger: ref.current, start: 'top 65%', end: 'bottom 65%', scrub: 1 },
        });
        gsap.utils.toArray<HTMLElement>('.processTimeline article').forEach((article) => {
          gsap.from(article, {
            opacity: 0.28,
            y: 28,
            duration: 0.65,
            ease: 'power3.out',
            scrollTrigger: { trigger: article, start: 'top 86%', once: true },
          });
        });
      }, ref);
    });
    return () => context?.revert();
  }, []);

  return (
    <section className="process" ref={ref} id="process">
      <div className="container">
        <div className="sectionHead"><span>החוויה</span><h2>שלושה שלבים. אפס ניחושים.</h2><p>אנימציית התהליך מלווה את הגלילה ומדגישה כל שלב בזמן הנכון.</p></div>
        <div className="processTimeline"><i className="processProgress" />
          {items.map(([number, title, text]) => <article key={number}><b>{number}</b><div><h3>{title}</h3><p>{text}</p></div></article>)}
        </div>
      </div>
    </section>
  );
}
