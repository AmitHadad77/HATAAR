const team = [
  ['א', 'אורי', 'פייד, קווים ועיצוב זקן', 'מתמחה במעברים מדורגים ובגימור חד שקל לשמור עליו לאורך זמן.'],
  ['ד', 'דניאל', 'מספריים וגילוח קלאסי', 'משלב טכניקה מסורתית עם התאמה מדויקת למבנה הפנים ולסגנון האישי.'],
  ['נ', 'נועם', 'טיפוח פנים וזקן', 'בונה שגרת טיפוח פשוטה ואפקטיבית שמתאימה לעור, לזקן ולחיי היום־יום.'],
] as const;

export default function Team() {
  return (
    <section id="team">
      <div className="container">
        <div className="sectionHead">
          <span>הצוות</span>
          <h2>מקצועיות שאפשר לראות. שירות שאפשר להרגיש.</h2>
          <p>כרטיסי הצוות הם תוכן דמו לתיק עבודות ויוחלפו בפרויקט אמיתי בצילומים ובביוגרפיות של אנשי העסק.</p>
        </div>
        <div className="teamGrid">
          {team.map(([letter, name, specialty, text]) => (
            <article key={name}>
              <div>{letter}</div><h3>{name}</h3><span>{specialty}</span><p>{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
