'use client';

import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';

const links = [
  ['#services', 'שירותים'],
  ['#story', 'החוויה'],
  ['#gallery', 'עבודות'],
  ['#team', 'הצוות'],
  ['#booking', 'תור'],
] as const;

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const update = () => setScrolled(window.scrollY > 28);
    update();
    window.addEventListener('scroll', update, { passive: true });
    return () => window.removeEventListener('scroll', update);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    const close = (event: KeyboardEvent) => event.key === 'Escape' && setOpen(false);
    window.addEventListener('keydown', close);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', close);
    };
  }, [open]);

  return (
    <>
      <header className={scrolled ? 'siteHeader scrolled' : 'siteHeader'}>
        <div className="nav">
          <a className="brand" href="#top" aria-label="התער — ראש העמוד">
            <span>ת</span>
            <div><b>התער</b><small>מספרת גברים · פתח תקווה</small></div>
          </a>
          <nav aria-label="ניווט ראשי">
            {links.map(([href, label]) => <a key={href} href={href}>{label}</a>)}
          </nav>
          <a className="button primary" href="#booking">שריין כיסא</a>
          <button className="menu" onClick={() => setOpen(true)} aria-label="פתיחת תפריט" aria-expanded={open}>
            <Menu />
          </button>
        </div>
      </header>

      {open && (
        <div className="mobileMenu" role="dialog" aria-modal="true" aria-label="תפריט ניווט">
          <button onClick={() => setOpen(false)} aria-label="סגירת תפריט"><X /></button>
          <div className="mobileMenuLinks">
            {links.map(([href, label]) => <a key={href} href={href} onClick={() => setOpen(false)}>{label}</a>)}
          </div>
        </div>
      )}
    </>
  );
}
