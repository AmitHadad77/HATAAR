const items = [
  {
    name: 'עידן כהן',
    text: 'אחרי שעברתי מלא ספרים באזור, סוף סוף מצאתי את המקום שלי. צוות מקצועי ברמות, אווירה מעולה ותספורת מדויקת על המילימטר.',
  },
  {
    name: 'רועי אברהם',
    text: 'הגילוח בתער הוא חוויה שכל גבר צריך לנסות. יחס אישי, פשוט לבוא, להירגע ולצאת כמו חדש.',
  },
  {
    name: 'דניאל תמיר',
    text: 'מקום מעולה. הפייד הכי נקי שקיבלתי, שירות עם חיוך ותוצאה שקל לשמור עליה גם בבית.',
  },
];

export default function Reviews() {
  return (
    <section id="reviews">
      <div className="container">
        <div className="sectionHead">
          <span>חוות דעת לדוגמה</span>
          <h2>המקום הנכון נמדד גם במה שמרגישים אחרי שיוצאים.</h2>
          <p className="disclaimer">הטקסטים והשמות משמשים תוכן דמו לתיק עבודות ויש להחליף אותם בביקורות מאומתות לפני פרסום מסחרי.</p>
        </div>
        <div className="reviewGrid">
          {items.map((item) => (
            <article key={item.name}>
              <b aria-label="חמישה כוכבים">★★★★★</b>
              <blockquote>“{item.text}”</blockquote>
              <footer>
                <strong>{item.name}</strong>
                <span>ביקורת לדוגמה · לא מאומתת</span>
              </footer>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
