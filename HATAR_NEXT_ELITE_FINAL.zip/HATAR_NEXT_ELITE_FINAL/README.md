# התער — Next.js Elite Final

גרסת תיק עבודות מלוטשת. הכותרת הראשית נשמרה ללא שינוי.

## מה בוצע
- קופירייטינג חדש לכל האזורים מלבד הכותרת הראשית
- Next Image בכל תמונות התוכן
- Hero WebP עם `priority`
- גלריית WebP מקומית עם Lightbox וניווט מקלדת
- ביקורות דמו מסומנות במפורש
- Scroll Progress ו-CTA קבוע במובייל
- FAQ, Booking ו-WhatsApp fallback
- GSAP נטען דינמית רק באזור התהליך
- Container Queries, Reduced Motion ו-RTL
- Build Production מלא עבר בהצלחה

## הרצה
```bash
npm install
npm run dev
```

## לפני פרסום מסחרי
יש להחליף מספר WhatsApp, פרטי עסק, תמונות הדמיה וביקורות דמו בפרטים אמיתיים.
